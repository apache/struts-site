package snippet;

import com.opensymphony.xwork.ActionSupport;

/**
 * @author Patrick Lightbody (plightbo at gmail dot com)
 */
public class Toggle extends ActionSupport {
    public String execute() throws Exception {
        SnippetMacro.TOGGLE = !SnippetMacro.TOGGLE;
        return NONE;
    }
}
